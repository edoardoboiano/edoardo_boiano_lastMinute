package com.example.demo.model;

public enum ProductType {

	BOOK,
	FOOD,
	MEDICAL,
	OTHER
}
