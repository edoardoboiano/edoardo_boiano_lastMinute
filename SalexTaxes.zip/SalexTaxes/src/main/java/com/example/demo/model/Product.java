package com.example.demo.model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import com.example.demo.configuration.TaxCostant;

import lombok.Data;

@Data
public class Product {

	private String name;
	private ProductType type;
	private Integer amount;
	private Boolean imported;
	private BigDecimal price;
	
	/**
	 * Get total of taxes on a set of identical products
	 * @return
	 */
	public BigDecimal calculateTaxes() {
		
		BigDecimal totalTaxes = BigDecimal.ZERO;
		
		BigDecimal totalTaxPercent = BigDecimal.ZERO;
		
		// calculate basic tax
		if(type == ProductType.OTHER) 
			totalTaxPercent = totalTaxPercent.add(TaxCostant.BASIC_TAX);
		
		if(imported)
			totalTaxPercent = totalTaxPercent.add(TaxCostant.IMPORT_TAX);
		
		BigDecimal importTax = price.multiply(totalTaxPercent).divide(new BigDecimal(100));
		totalTaxes = totalTaxes.add(roundValue(importTax).multiply(new BigDecimal(amount)));
			
		return totalTaxes;
	}
	
	/**
	 * Get total price on a set of identical products
	 * @return
	 */
	public BigDecimal calculateTotalPrice() {
		 
		return price.add(calculateTaxes());
	}
	
	/**
	 * Round the value up to the nearest 0.05 
	 * @param value
	 * @return
	 */
	private BigDecimal roundValue(BigDecimal value) {	
		
		return value.multiply(new BigDecimal(20)).setScale(0, RoundingMode.HALF_UP).divide(new BigDecimal(20));
	}
}
