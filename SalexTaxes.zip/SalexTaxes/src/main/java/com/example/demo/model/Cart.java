package com.example.demo.model;

import java.math.BigDecimal;
import java.util.List;

import lombok.Data;

@Data
public class Cart {
	
	private List<Product> products;
	private BigDecimal salexTaxes;
	private BigDecimal total;
	
	public void insertProducts(List<Product> products) {
		
		this.products = products;
		setSalexTaxes(calculateCartTaxes());
		setTotal(calculateCartTotalPrice());
	}
	
	public BigDecimal calculateCartTaxes() {
		
		BigDecimal result = BigDecimal.ZERO;
		
		for(Product p : products)
			result = result.add(p.calculateTaxes());
		
		return result;
	}
	
	public BigDecimal calculateCartTotalPrice() {
		
		BigDecimal result = BigDecimal.ZERO;
		
		for(Product p : products) {
			BigDecimal totalPrice = p.calculateTotalPrice();
			p.setPrice(totalPrice);
			result = result.add(totalPrice);
		}
		
		setTotal(result);
		return result;
	}
}
