package com.example.demo.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.example.demo.exception.exceptions.DataException;

@ControllerAdvice
public class GlobalExceptionController {

	@ExceptionHandler(value = DataException.class)
	public ResponseEntity<String> exception(DataException exception) {
		
		return new ResponseEntity<>(exception.getError(), HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<String> exception(Exception exception) {
		
		return new ResponseEntity<>(exception.getMessage(), HttpStatus.BAD_REQUEST);
	}
}
