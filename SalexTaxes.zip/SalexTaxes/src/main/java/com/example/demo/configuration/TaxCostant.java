package com.example.demo.configuration;

import java.math.BigDecimal;

public class TaxCostant {

	public static BigDecimal BASIC_TAX;
	public static BigDecimal IMPORT_TAX;
	
	static {
		
		BASIC_TAX = new BigDecimal(10);
		IMPORT_TAX = new BigDecimal(5);
	}
}
