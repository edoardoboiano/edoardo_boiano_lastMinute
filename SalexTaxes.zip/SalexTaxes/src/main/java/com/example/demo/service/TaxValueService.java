package com.example.demo.service;

import java.math.BigDecimal;

import org.springframework.stereotype.Service;

import com.example.demo.configuration.TaxCostant;
import com.example.demo.exception.exceptions.DataException;
import com.example.demo.model.TaxType;
import com.example.demo.model.TaxValue;

@Service
public class TaxValueService {
	
	public String setTaxValue(TaxValue taxValue) {
		
		TaxType type = taxValue.getType();
		BigDecimal newValue = taxValue.getValue();
		
		switch(type) {
		
			case BASIC_TAX:
				TaxCostant.BASIC_TAX = newValue;
				return "New value for BASIC_TAX: "+newValue;
			case IMPORT_TAX:
				TaxCostant.IMPORT_TAX = newValue;
				return "New value for IMPORT_TAX: "+newValue;
			default:
				return "No type found";
		}
	}
	
	public void validBody(TaxValue body) {
		
		if(body.getType() == null)
			throw new DataException("Type of tax is not defined");
		if(body.getValue() == null)
			throw new DataException("Value is not defined");
	}
}
