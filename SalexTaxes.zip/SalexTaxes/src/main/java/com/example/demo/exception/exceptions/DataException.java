package com.example.demo.exception.exceptions;

import lombok.Getter;

public class DataException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	@SuppressWarnings("unused")
	private String error;
	
	public DataException(String error) {
		super();
		this.error = error;
	}
	
	public String getError() {
		return error;
	}
}
