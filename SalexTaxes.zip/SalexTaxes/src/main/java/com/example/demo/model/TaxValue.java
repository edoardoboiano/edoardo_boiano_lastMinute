package com.example.demo.model;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class TaxValue {

	private TaxType type;
	private BigDecimal value;
}
