package com.example.demo.model;

public enum TaxType {

	BASIC_TAX,
	IMPORT_TAX
}
