package com.example.demo.api;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Cart;
import com.example.demo.model.Product;
import com.example.demo.model.TaxValue;
import com.example.demo.service.SalesTaxesService;
import com.example.demo.service.TaxValueService;

@RestController
public class SalesTaxesApiDelegate {

	@Autowired
	SalesTaxesService salexTaxesService;
	
	@Autowired
	TaxValueService taxValueService;
	
	@RequestMapping(value = "/items", method = RequestMethod.POST)
	public ResponseEntity<Cart> insertItems(@RequestBody List<Product> products) {
		
		Cart responseBody = salexTaxesService.insertItems(products);
		return new ResponseEntity<Cart>(responseBody, HttpStatus.OK);
	}
	
	@RequestMapping(value = "/tax_values", method = RequestMethod.POST)
	public ResponseEntity<String> setTaxValue(@RequestBody TaxValue body) {
		
		String response = taxValueService.setTaxValue(body);
		return new ResponseEntity<String>(response, HttpStatus.OK);
	}

	public void setSalexTaxesService(SalesTaxesService salexTaxesService) {
		this.salexTaxesService = salexTaxesService;
	}
	
	
}
