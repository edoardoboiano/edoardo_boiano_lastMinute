package com.example.demo.service;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.exception.exceptions.DataException;
import com.example.demo.model.Cart;
import com.example.demo.model.Product;

@Service
public class SalesTaxesService {
	
	/**
	 * insert items in the cart and calculate total taxes and price
	 * @param products
	 * @return
	 */
	public Cart insertItems(List<Product> products) {
		
		Cart response = new Cart();
		
		validateProducts(products);
		response.insertProducts(products);
		return response;
	}
	
	public void validateProducts(List<Product> products) {
		
		for(Product p : products) {
			
			if(p.getType() == null)
				throw new DataException("No type given");
			if(p.getAmount() == null)
				p.setAmount(1);
			else if(p.getAmount() < 0)
				throw new DataException("Amount is negative");
			if(p.getImported() == null)
				throw new DataException("Imported not defined");
			if(p.getPrice() == null)
				throw new DataException("Price not defined");
			else if(p.getPrice().compareTo(BigDecimal.ZERO) < 0)
				throw new DataException("Price is negative");
		}
	}
}
