# SALES TAXES
This is a spring boot microservice that takes a list of products as input and calculates for every item the tax amount and the total price.
It's also possible changing the value of the sale tax.
# PRODUCTS INPUT EXAMPLE

http://localhost:8080/items

[
    {
        "name": "book",
        "type": "BOOK",
        "amount": 1,
        "imported": false,
        "price": 12.49
    },
    {
        "name": "music CD",
        "type": "OTHER",
        "amount": 1,
        "imported": false,
        "price": 14.99
    },
    {
        "name": "chocolate bar",
        "type": "FOOD",
        "amount": 1,
        "imported": false,
        "price": 0.85
    }
]

# TAX_VALUE INPUT EXAMPLE

http://localhost:8080/tax_values

{
    "type": "BASIC_TAX",
    "value": 12.0
}
